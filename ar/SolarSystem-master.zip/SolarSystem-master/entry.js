let solar = require('./solar/SolarSystem.js');

solar.init();